package goldenraspberryawards.controller;

import goldenraspberryawards.entity.Filme;
import goldenraspberryawards.repository.FilmeRepository;
import org.junit.jupiter.params.shadow.com.univocity.parsers.common.record.Record;
import org.junit.jupiter.params.shadow.com.univocity.parsers.csv.CsvParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ImportaController {

    @Autowired
    FilmeRepository filmeRepository;

    @PostMapping("/upload")
    public String uploadData(@RequestParam("file")MultipartFile file) throws Exception{

        List<Filme> filmeList = new ArrayList<>();
        InputStream inputStream = file.getInputStream();

        org.junit.jupiter.params.shadow.com.univocity.parsers.csv.CsvParserSettings setting = new org.junit.jupiter.params.shadow.com.univocity.parsers.csv.CsvParserSettings();
        setting.getFormat().setDelimiter(';');
        setting.getFormat().setLineSeparator("\n");
        setting.setHeaderExtractionEnabled(true);
        CsvParser parser = new CsvParser(setting);
        List<Record> parseAllRercords = parser.parseAllRecords(inputStream);
        parseAllRercords.forEach(record -> {
            Filme filme = new Filme();
            filme.setFilm_year(Integer.parseInt(record.getString("year")));
            filme.setFilm_title(record.getString("title"));
            filme.setFilm_studios(record.getString("studios"));
            filme.setFilm_producers(record.getString("producers"));
            filme.setFilm_winner(record.getString("winner"));
            filmeList.add(filme);
        });
        filmeRepository.saveAll(filmeList);
        return "Sucesso ao importar!";
    }
}
