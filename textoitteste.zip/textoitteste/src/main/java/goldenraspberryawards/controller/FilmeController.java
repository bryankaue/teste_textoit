package goldenraspberryawards.controller;

import goldenraspberryawards.entity.Filme;
import goldenraspberryawards.service.FilmeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/filme")
public class FilmeController {
    @Autowired
    private FilmeService filmeService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Filme salvar(@RequestBody Filme filme){
        return filmeService.salvar(filme);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Filme> listaFilme(){
        return filmeService.listaFilme();
    }

    @GetMapping("/{film_id}")
    @ResponseStatus(HttpStatus.OK)
    public Filme buscarFilmePorId(@PathVariable("film_id") Long id){
        return filmeService.buscarPorId(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Não encontrado!"));

    }

    @DeleteMapping("/{film_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerFilme(@PathVariable("film_id") Long id){
        filmeService.buscarPorId(id).map(filme -> {
            filmeService.removerPorId(filme.getFilm_id());
            return Void.TYPE;
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Não encontrado!."));
    }

}
