package goldenraspberryawards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoldenRaspberryAwards {

	public static void main(String[] args) {
		SpringApplication.run(GoldenRaspberryAwards.class, args);
	}

}
