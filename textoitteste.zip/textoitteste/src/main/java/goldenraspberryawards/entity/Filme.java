package goldenraspberryawards.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Data //CRIA GETTERS AND SETTERS AUTOMATICO
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Filme implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long film_id;

    private Integer film_year;
    private String film_title;
    private String film_studios;
    private String film_producers;
    private String film_winner;

}
