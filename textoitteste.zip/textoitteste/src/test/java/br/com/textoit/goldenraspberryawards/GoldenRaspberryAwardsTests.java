package br.com.textoit.goldenraspberryawards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoldenRaspberryAwardsTests {

	@Test
	void contextLoads() {
	}

}
